﻿using System;
namespace Lab5
{
    public class ClassModel
    {
        public long Id { get; set; }

    }
}
